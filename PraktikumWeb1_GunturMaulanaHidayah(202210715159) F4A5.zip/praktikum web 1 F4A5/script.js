// script.js

document.addEventListener('DOMContentLoaded', function () {
    const deleteLinks = document.querySelectorAll('.delete-link');
    const confirmDialog = document.getElementById('confirmDialog');
    const confirmYes = document.getElementById('confirmYes');
    const confirmNo = document.getElementById('confirmNo');
    let currentDeleteLink;
  
    deleteLinks.forEach(link => {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        currentDeleteLink = link;
        confirmDialog.style.display = 'block';
      });
    });
  
    confirmYes.addEventListener('click', function () {
      const itemId = currentDeleteLink.getAttribute('data-id');
      window.location.href = 'delete.php?id=' + itemId;
    });
  
    confirmNo.addEventListener('click', function () {
      confirmDialog.style.display = 'none';
    });
  });
  