<?php
include('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$name = $_POST['name'];
$quantity = $_POST['quantity'];

$sql = "INSERT INTO items (name, quantity) VALUES ('$name', '$quantity')";

if ($conn->query($sql) === TRUE) {
header('Location: index.php');
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add New Item</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Add New Item</h1>
<form action="add.php" method="post">
<label for="name">Name:</label>
<input type="text" id="name" name="name" required>
<label for="quantity">Quantity:</label>
<input type="number" id="quantity" name="quantity" required>
<button type="submit">Add Item</button>

</form>
<a href="index.php">Back to Inventory</a>
</body>
</html>