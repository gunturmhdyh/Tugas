<?php include('config.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h1>Inventory Management</h1>
    <a href="add.php">Add New Item</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM items";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>

<td>" . $row["id"] . "</td>
<td>" . $row["name"] . "</td>
<td>" . $row["quantity"] . "</td>
<td>
<a href='edit.php?id=" . $row["id"] . "'>Edit</a>
<a href='delete.php?id=" . $row["id"] . "' onclick='return confirm(\"Are
you sure?\")'>Delete</a>
</td>
</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No items found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>

</html>